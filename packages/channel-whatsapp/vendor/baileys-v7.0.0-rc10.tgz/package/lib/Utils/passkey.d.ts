import { proto } from '../../WAProto/index.js';
import type { PasskeyCredentialResponse, PasskeyPublicKeyCredentialRequestOptions, WABrowserDescription } from '../Types/index.js';
import { Curve } from './crypto.js';
export type PasskeyLinkingCache = {
    keyPair: ReturnType<typeof Curve.generateKeyPair>;
    companionNonce: Buffer;
    pairingRef: string;
    deviceType: proto.DeviceProps.PlatformType;
    encryptionKey?: Buffer;
};
export declare const parsePasskeyRequestOptions: (content: Buffer) => PasskeyPublicKeyCredentialRequestOptions;
export declare const parsePasskeyCredentialResponse: (input: unknown) => PasskeyCredentialResponse;
export declare const getPasskeyDeviceType: (browser: WABrowserDescription) => proto.DeviceProps.PlatformType;
export declare const derivePasskeyHandoffKey: (advSecretKey: string) => Buffer;
export declare const buildPasskeyPrologue: ({ credential, pairingRef, browser, handoffKey, keyPair, companionNonce }: {
    credential: PasskeyCredentialResponse;
    pairingRef: string;
    browser: WABrowserDescription;
    handoffKey?: Buffer;
    keyPair?: ReturnType<typeof Curve.generateKeyPair>;
    companionNonce: Buffer;
}) => {
    content: BinaryPasskeyNode[];
    payload: Buffer;
    cache: PasskeyLinkingCache;
    skipHandoffUX: boolean;
};
export declare const continuePasskeyPairing: ({ cache, primaryIdentity }: {
    cache: PasskeyLinkingCache;
    primaryIdentity: proto.IPrimaryEphemeralIdentity;
}) => {
    cache: PasskeyLinkingCache;
    code: string;
};
export declare const buildEncryptedPasskeyPairingRequest: ({ cache, noisePublicKey, identityPublicKey, advSecretKey, iv }: {
    cache: PasskeyLinkingCache;
    noisePublicKey: Uint8Array;
    identityPublicKey: Uint8Array;
    advSecretKey: string;
    iv: Buffer;
}) => Buffer;
type BinaryPasskeyNode = {
    tag: string;
    attrs: Record<string, string>;
    content: Buffer;
};
export {};
//# sourceMappingURL=passkey.d.ts.map